const express = require("express");
const router = express.Router();
const data = require("../data/sampleData.json");
router.get("/", (req, res) => res.json(data.staff));
module.exports = router;