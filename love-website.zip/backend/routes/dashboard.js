const express = require("express");
const router = express.Router();
const data = require("../data/sampleData.json");
router.get("/", (req, res) => {
  const stats = { totalSales: 50000, totalOrders: 120, totalProfit: 20000, lowStockCount: 5 };
  const topProducts = data.products;
  res.json({ stats, topProducts });
});
module.exports = router;