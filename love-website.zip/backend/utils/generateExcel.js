const XLSX = require("xlsx");
const bwipjs = require("bwip-js");
const cron = require("node-cron");
const { sendEmailWithAttachment } = require("./sendEmail");
const data = require("../data/sampleData.json");
const generateBarcodeBase64 = async (text) => new Promise((resolve, reject) => {
  bwipjs.toBuffer({ bcid: "code128", text, scale: 3, height: 10, includetext: true, textxalign: "center" }, (err, png) => {
    if(err) reject(err); else resolve(`data:image/png;base64,${png.toString("base64")}`);
  });
});
const generateExcelReport = async () => {
  const wb = XLSX.utils.book_new();
  const stats = { totalSales: 50000, totalOrders: 120, totalProfit: 20000, lowStockCount: 5 };
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([["Total Sales", stats.totalSales], ["Total Orders", stats.totalOrders], ["Total Profit", stats.totalProfit], ["Low Stock Count", stats.lowStockCount]]), "Summary");
  const products = await Promise.all(data.products.map(async (p) => ({ ...p, Barcode: await generateBarcodeBase64(p.id) })));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(products), "Top Products");
  const staff = await Promise.all(data.staff.map(async (s) => ({ ...s, Barcode: await generateBarcodeBase64(s.id) })));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(staff), "Staff Payments");
  const filePath = "./monthly_dashboard.xlsx";
  XLSX.writeFile(wb, filePath);
  return filePath;
};
const scheduleMonthlyReport = () => {
  cron.schedule("0 8 1 * *", async () => {
    try {
      const filePath = await generateExcelReport();
      await sendEmailWithAttachment("Monthly Dashboard Report", "dashboard.xlsx", filePath);
      console.log("✅ Report generated and emailed.");
    } catch (err) { console.error(err); }
  });
};
module.exports = { generateExcelReport, scheduleMonthlyReport };