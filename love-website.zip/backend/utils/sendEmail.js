const nodemailer = require("nodemailer");
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: { user: "your-email@gmail.com", pass: "your-app-password" },
});
const sendEmailWithAttachment = async (subject, filename, path) => {
  await transporter.sendMail({
    from: "your-email@gmail.com",
    to: "recipient-email@gmail.com",
    subject,
    text: "Attached is your report.",
    attachments: [{ filename, path }]
  });
};
module.exports = { sendEmailWithAttachment };