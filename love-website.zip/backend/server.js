const express = require("express");
const cors = require("cors");
const dashboardRoutes = require("./routes/dashboard");
const staffRoutes = require("./routes/staff");
const productRoutes = require("./routes/products");
const { scheduleMonthlyReport } = require("./utils/generateExcel");
const app = express();
app.use(cors());
app.use(express.json());
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/staff", staffRoutes);
app.use("/api/products", productRoutes);
app.listen(5000, () => {
  console.log("Backend running on http://localhost:5000");
  scheduleMonthlyReport();
});