import Barcode from 'react-barcode';
export default function ProductCard({product}){ return <div><h2>{product.name}</h2><Barcode value={product.id} format="CODE128" /></div>; }