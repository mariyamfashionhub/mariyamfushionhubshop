import { useEffect, useState } from "react";
import axios from "axios";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import bwipjs from "bwip-js";
export default function AdminDashboard() {
  const [stats,setStats]=useState({}); const [topProducts,setTopProducts]=useState([]); const [staff,setStaff]=useState([]);
  useEffect(()=>{ fetchData(); },[]);
  const fetchData=async()=>{ const res1=await axios.get("http://localhost:5000/api/dashboard"); setStats(res1.data.stats); setTopProducts(res1.data.topProducts);
  const res2=await axios.get("http://localhost:5000/api/staff"); setStaff(res2.data); };
  const generateBarcodeBase64=async(text)=>new Promise((resolve,reject)=>{ bwipjs.toBuffer({ bcid:"code128", text, scale:3, height:10, includetext:true },(err,png)=>{ if(err)reject(err); else resolve(`data:image/png;base64,${png.toString("base64")}`); }); });
  const exportToExcel=async()=>{ const wb=XLSX.utils.book_new();
    const summary=[["Total Sales",stats.totalSales],["Total Orders",stats.totalOrders],["Total Profit",stats.totalProfit],["Low Stock Count",stats.lowStockCount]];
    XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(summary),"Summary");
    const productsWithBarcode=await Promise.all(topProducts.map(async p=>({...p,Barcode:await generateBarcodeBase64(p.id)})));
    XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(productsWithBarcode),"Top Products");
    const staffWithBarcode=await Promise.all(staff.map(async s=>({...s,Barcode:await generateBarcodeBase64(s.id)})));
    XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(staffWithBarcode),"Staff Payments");
    const wbout=XLSX.write(wb,{bookType:"xlsx",type:"array"});
    saveAs(new Blob([wbout],{type:"application/octet-stream"}),"dashboard_report.xlsx"); };
  return (<div className="p-6"><h1 className="text-3xl font-bold mb-6">📊 Admin Dashboard</h1><button onClick={exportToExcel} className="bg-green-600 text-white px-4 py-2 rounded shadow hover:bg-green-700">📥 Export Excel</button></div>);
}